from django.apps import AppConfig


class HairStyleConfig(AppConfig):
    name = 'Hair_style'
